package com.vinhcommand.data.repository

import com.vinhcommand.data.local.*
import com.vinhcommand.data.mapper.TaskMapper
import com.vinhcommand.domain.model.*
import com.vinhcommand.domain.repository.TaskRepository
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.serialization.encodeToString
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TaskRepositoryImpl @Inject constructor(
    private val taskDao: TaskDao
) : TaskRepository {

    private val outputChannel = Channel<Pair<String, String>>()

    override suspend fun getTasks(): Result<List<AgentTask>> {
        return try {
            val entities = taskDao.getAll().first()
            Result.success(TaskMapper.toDomainList(entities))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun getTask(id: String): Result<AgentTask> {
        return try {
            val entity = taskDao.getById(id)
            entity?.let { Result.success(TaskMapper.toDomain(it)) } ?: Result.failure(Exception("Task not found"))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun createTask(request: CreateTaskRequest): Result<AgentTask> {
        return Result.failure(Exception("Must be implemented with network"))
    }

    override suspend fun controlTask(request: TaskControlRequest): Result<Unit> {
        return Result.failure(Exception("Must be implemented with network"))
    }

    override suspend fun getTaskOutput(taskId: String): Result<List<String>> {
        return try {
            val entity = taskDao.getById(taskId)
            entity?.let { Result.success(TaskMapper.toDomain(it).logs) } ?: Result.failure(Exception("Task not found"))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun getTaskTimeline(taskId: String): Result<List<TaskTimelineEvent>> {
        return try {
            val entity = taskDao.getById(taskId)
            entity?.let { Result.success(TaskMapper.toDomain(it).timeline) } ?: Result.failure(Exception("Task not found"))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun getTaskDiff(taskId: String): Result<GitDiff?> {
        return try {
            val entity = taskDao.getById(taskId)
            entity?.let { Result.success(TaskMapper.toDomain(it).gitDiff) } ?: Result.failure(Exception("Task not found"))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override val tasksFlow: Flow<List<AgentTask>>
        get() = taskDao.getAll().map { TaskMapper.toDomainList(it) }

    override val taskOutputFlow: Flow<Pair<String, String>>
        get() = outputChannel.receiveAsFlow()

    fun onTaskOutput(taskId: String, line: String) {
        outputChannel.trySend(taskId to line)
    }
}
