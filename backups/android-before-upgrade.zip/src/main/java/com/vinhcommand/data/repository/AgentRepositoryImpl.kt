package com.vinhcommand.data.repository

import com.vinhcommand.data.local.*
import com.vinhcommand.data.mapper.AgentMapper
import com.vinhcommand.domain.model.*
import com.vinhcommand.domain.repository.AgentRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.serialization.encodeToString
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AgentRepositoryImpl @Inject constructor(
    private val agentDao: AgentDao
) : AgentRepository {

    override suspend fun getAgents(): Result<List<AIAgent>> {
        return try {
            val entities = agentDao.getAll().first()
            Result.success(AgentMapper.toDomainList(entities))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun getAgent(id: String): Result<AIAgent> {
        return try {
            val entity = agentDao.getById(id)
            entity?.let { Result.success(AgentMapper.toDomain(it)) } ?: Result.failure(Exception("Agent not found"))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun getAgentDetail(id: String): Result<AgentDetail> {
        return Result.failure(Exception("Not implemented locally"))
    }

    override suspend fun launchAgent(agentId: String, projectId: String?): Result<Unit> {
        return Result.failure(Exception("Must be implemented with network"))
    }

    override suspend fun stopAgent(agentId: String): Result<Unit> {
        return Result.failure(Exception("Must be implemented with network"))
    }

    override suspend fun sendPrompt(agentId: String, prompt: String, projectId: String): Result<String> {
        return Result.failure(Exception("Must be implemented with network"))
    }

    override val agentsFlow: Flow<List<AIAgent>>
        get() = agentDao.getAll().map { AgentMapper.toDomainList(it) }
}
