package com.vinhcommand.data.repository

import com.vinhcommand.data.local.*
import com.vinhcommand.data.mapper.*
import com.vinhcommand.domain.model.*
import com.vinhcommand.domain.repository.ConnectionRepository
import com.vinhcommand.network.api.VinhCommandApi
import com.vinhcommand.network.model.*
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.MutableStateFlow
import retrofit2.Response
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ConnectionRepositoryImpl @Inject constructor(
    private val api: VinhCommandApi,
    private val computerRepository: ComputerRepositoryImpl,
    private val projectRepository: ProjectRepositoryImpl,
    private val agentRepository: AgentRepositoryImpl,
    private val taskRepository: TaskRepositoryImpl,
    private val processRepository: ProcessRepositoryImpl,
    private val serverRepository: ServerRepositoryImpl,
    private val securityRepository: SecurityRepositoryImpl,
    private val sessionStateDao: SessionStateDao,
    private val deviceInfoDao: DeviceInfoDao
) : ConnectionRepository {

    private val connectionState = MutableStateFlow<ConnectionState>(ConnectionState.DISCONNECTED)
    private val pcStateChannel = Channel<PcState>()
    private var currentConfig: ConnectionConfig? = null
    private var sessionToken: String? = null

    override suspend fun connect(config: ConnectionConfig): Result<AuthResponse> {
        currentConfig = config
        connectionState.value = ConnectionState.CONNECTING

        return try {
            val request = ConnectRequest(
                desktopId = config.desktopId.replace(" ", ""),
                accessCode = currentConfig?.accessCode ?: "", // Use accessCode from config if available
                deviceId = "android_device",
                deviceName = "Android Device",
                appVersion = "1.0.0"
            )
            
            val response: Response<ApiResponse<ConnectResponse>> = api.connect(request)
            
            if (response.isSuccessful && response.body()?.success == true) {
                val body = response.body()!!
                sessionToken = body.data?.sessionToken
                connectionState.value = ConnectionState.CONNECTED
                
                // Save computer if provided
                body.data?.computer?.let { computer ->
                    computerRepository.saveComputer(computer)
                }
                
                Result.success(AuthResponse(
                    success = true,
                    sessionToken = sessionToken,
                    refreshToken = body.data?.refreshToken,
                    expiresIn = body.data?.expiresIn,
                    deviceTrusted = body.data?.deviceTrusted ?: false,
                    error = null
                ))
            } else {
                connectionState.value = ConnectionState.FAILED
                val errorMsg = response.body()?.error?.message ?: "Connection failed"
                Result.failure(RuntimeException(errorMsg))
            }
        } catch (e: Exception) {
            connectionState.value = ConnectionState.FAILED
            Result.failure(e)
        }
    }

    override suspend fun disconnect(): Result<Unit> {
        connectionState.value = ConnectionState.DISCONNECTED
        sessionToken = null
        return Result.success(Unit)
    }

    override suspend fun pair(request: PairingRequest): Result<PairingChallenge> {
        connectionState.value = ConnectionState.CONNECTING
        return try {
            val apiRequest = PairRequest(
                desktopId = request.desktopId,
                deviceName = request.deviceName,
                deviceType = request.deviceType,
                platform = request.platform,
                appVersion = request.appVersion
            )
            val response: Response<ApiResponse<PairResponse>> = api.pair(apiRequest)
            if (response.isSuccessful && response.body()?.success == true) {
                val body = response.body()!!
                connectionState.value = ConnectionState.AUTHENTICATING
                Result.success(PairingChallenge(
                    challengeId = body.data?.challengeId ?: "",
                    desktopId = request.desktopId,
                    qrCodeData = body.data?.qrCodeData ?: "",
                    expiresAt = body.data?.expiresAt ?: ""
                ))
            } else {
                connectionState.value = ConnectionState.FAILED
                val errorMsg = response.body()?.error?.message ?: "Pairing failed"
                Result.failure(RuntimeException(errorMsg))
            }
        } catch (e: Exception) {
            connectionState.value = ConnectionState.FAILED
            Result.failure(e)
        }
    }

    override suspend fun authenticate(request: AuthRequest): Result<AuthResponse> {
        connectionState.value = ConnectionState.AUTHENTICATING
        return try {
            val authRequest = ConnectRequest(
                desktopId = request.desktopId.replace(" ", ""),
                accessCode = request.accessCode,
                deviceId = request.deviceId,
                deviceName = request.deviceName,
                appVersion = "1.0.0"
            )
            
            val response: Response<ApiResponse<ConnectResponse>> = api.connect(authRequest)
            
            if (response.isSuccessful && response.body()?.success == true) {
                val body = response.body()!!
                sessionToken = body.data?.sessionToken
                connectionState.value = ConnectionState.CONNECTED
                
                body.data?.computer?.let { computer ->
                    computerRepository.saveComputer(computer)
                }
                
                Result.success(AuthResponse(
                    success = true,
                    sessionToken = sessionToken,
                    refreshToken = body.data?.refreshToken,
                    expiresIn = body.data?.expiresIn,
                    deviceTrusted = body.data?.deviceTrusted ?: false,
                    error = null
                ))
            } else {
                connectionState.value = ConnectionState.ACCESS_REVOKED
                val errorMsg = response.body()?.error?.message ?: "Authentication failed"
                Result.failure(RuntimeException(errorMsg))
            }
        } catch (e: Exception) {
            connectionState.value = ConnectionState.FAILED
            Result.failure(e)
        }
    }

    override suspend fun trustDevice(request: DeviceTrustRequest): Result<Unit> {
        return Result.failure(Exception("Must be implemented"))
    }

    override suspend fun refreshSession(): Result<AuthResponse> {
        return Result.failure(Exception("Not implemented"))
    }

    override val connectionStateFlow: Flow<ConnectionState> = connectionState

    override val pcStateFlow: Flow<PcState> = pcStateChannel.receiveAsFlow()

    fun updatePcState(
        computer: DesktopComputer?,
        projects: List<Project>,
        agents: List<AIAgent>,
        tasks: List<AgentTask>,
        processes: List<ProcessItem>,
        servers: List<DevServer>,
        hardwareStats: HardwareStats?
    ) {
        pcStateChannel.trySend(PcState(
            computer = computer,
            projects = projects,
            agents = agents,
            tasks = tasks,
            processes = processes,
            servers = servers,
            hardwareStats = hardwareStats,
            lastUpdated = System.currentTimeMillis()
        ))
    }
}
