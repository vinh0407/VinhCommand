package com.vinhcommand.presentation.connect

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Computer
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.vinhcommand.presentation.common.BaseViewModel
import com.vinhcommand.ui.theme.VinhCommandTheme

@Composable
fun ConnectScreen(
    onNavigateToHome: () -> Unit,
    viewModel: ConnectViewModel = hiltViewModel()
) {
    val connectionState by viewModel.connectionState.collectAsStateWithLifecycle()
    val pcState by viewModel.pcState.collectAsStateWithLifecycle()
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val desktopId by viewModel.desktopId.collectAsStateWithLifecycle()
    val accessCode by viewModel.accessCode.collectAsStateWithLifecycle()
    val isPairingMode by viewModel.isPairingMode.collectAsStateWithLifecycle()
    val pairingChallenge by viewModel.pairingChallenge.collectAsStateWithLifecycle()
    
    VinhCommandTheme {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Logo/Title
                Text(
                    text = "VINHCOMMAND",
                    style = MaterialTheme.typography.headlineLarge,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "AI AGENT COMMAND CENTER",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(48.dp))

                if (isPairingMode) {
                    PairingScreen(
                        challenge = pairingChallenge,
                        onAuthenticate = { viewModel.authenticate() },
                        onBack = { viewModel.setPairingMode(false) },
                        viewModel = viewModel
                    )
                } else {
                    ConnectFormScreen(
                        desktopId = desktopId,
                        onDesktopIdChange = { viewModel.setDesktopId(it) },
                        accessCode = accessCode,
                        onAccessCodeChange = { viewModel.setAccessCode(it) },
                        onConnect = { viewModel.connect() },
                        onPair = { viewModel.pair() },
                        onNavigateToHome = onNavigateToHome,
                        connectionState = connectionState,
                        pcState = pcState,
                        uiState = uiState,
                        viewModel = viewModel
                    )
                }
            }
        }
    }
}

@Composable
fun ConnectFormScreen(
    desktopId: String,
    onDesktopIdChange: (String) -> Unit,
    accessCode: String,
    onAccessCodeChange: (String) -> Unit,
    onConnect: () -> Unit,
    onPair: () -> Unit,
    onNavigateToHome: () -> Unit,
    connectionState: com.vinhcommand.domain.model.ConnectionState,
    pcState: com.vinhcommand.domain.model.PcState,
    uiState: BaseViewModel.UiState,
    viewModel: ConnectViewModel
) {
    Column(
        modifier = Modifier.width(320.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Connection status indicator
        if (connectionState != com.vinhcommand.domain.model.ConnectionState.DISCONNECTED) {
            ConnectionStatusIndicator(state = connectionState)
            Spacer(modifier = Modifier.height(16.dp))
        }

        // PC Info if connected
        pcState.computer?.let { computer ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Column(
                    modifier = Modifier.padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Computer,
                                contentDescription = "Computer",
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = computer.name,
                                    style = MaterialTheme.typography.bodyLarge,
                                    fontWeight = FontWeight.Medium
                                )
                                Text(
                                    text = "ID: ${computer.desktopId} • ${computer.os}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        AssistChip(
                            onClick = { onNavigateToHome() },
                            label = { Text("CONNECTED") },
                            colors = AssistChipDefaults.assistChipColors(
                                containerColor = MaterialTheme.colorScheme.tertiaryContainer
                            )
                        )
                    }
                }
            }
        }

        // Desktop ID Input
        TextField(
            value = desktopId,
            onValueChange = onDesktopIdChange,
            label = { Text("Desktop ID") },
            placeholder = { Text("842 193 775") },
            leadingIcon = { Icon(
                imageVector = Icons.Default.QrCode,
                contentDescription = "Scan QR",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.clickable { onPair() }
            )},
            trailingIcon = { if (desktopId.isNotBlank()) Icon(
                imageVector = Icons.Default.CheckCircle,
                contentDescription = "Valid",
                tint = MaterialTheme.colorScheme.tertiary
            ) else null },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            visualTransformation = DesktopIdVisualTransformation(),
            isError = desktopId.isNotBlank() && !viewModel.validateDesktopId(desktopId)
        )

        // Access Code Input
        TextField(
            value = accessCode,
            onValueChange = onAccessCodeChange,
            label = { Text("Access Code") },
            placeholder = { Text("• • • • • •") },
            trailingIcon = { if (accessCode.isNotBlank()) Icon(
                imageVector = Icons.Default.CheckCircle,
                contentDescription = "Valid",
                tint = MaterialTheme.colorScheme.tertiary
            ) else null },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            visualTransformation = PasswordVisualTransformation(),
            isError = accessCode.isNotBlank() && !viewModel.validateAccessCode(accessCode)
        )

        // Error/Loading state
        when (uiState) {
            is BaseViewModel.UiState.Error -> {
                Text(
                    text = uiState.message,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall
                )
            }
            is BaseViewModel.UiState.Loading -> {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CircularProgressIndicator(modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(text = uiState.message)
                }
            }
            is BaseViewModel.UiState.Success<*> -> {
                Text(
                    text = "Connected successfully!",
                    color = MaterialTheme.colorScheme.tertiary,
                    style = MaterialTheme.typography.bodySmall
                )
                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = onNavigateToHome,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Continue to Command Center")
                }
            }
            else -> {}
        }

        // Connect Button
        Button(
            onClick = onConnect,
            enabled = viewModel.validateDesktopId(desktopId) && viewModel.validateAccessCode(accessCode),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = "CONNECT",
                fontWeight = FontWeight.Bold
            )
        }

        // Pair button
        TextButton(
            onClick = onPair,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Or pair with QR code")
        }
    }
}

@Composable
fun PairingScreen(
    challenge: com.vinhcommand.domain.model.PairingChallenge?,
    onAuthenticate: () -> Unit,
    onBack: () -> Unit,
    viewModel: ConnectViewModel
) {
    val accessCode by viewModel.accessCode.collectAsStateWithLifecycle()
    
    Column(
        modifier = Modifier.width(320.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = Icons.Default.PhoneAndroid,
            contentDescription = "Pairing",
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(64.dp)
        )
        Text(
            text = "Pair Device",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "Enter the access code shown on your PC",
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        
        challenge?.let { c ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Column(
                    modifier = Modifier.padding(16.dp)
                ) {
                    Text(
                        text = "Pairing Challenge",
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = c.qrCodeData,
                        style = MaterialTheme.typography.bodySmall,
                        fontFamily = FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        TextField(
            value = accessCode,
            onValueChange = { viewModel.setAccessCode(it) },
            label = { Text("Access Code") },
            placeholder = { Text("• • • • • •") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            visualTransformation = PasswordVisualTransformation()
        )

        Button(
            onClick = onAuthenticate,
            enabled = accessCode.length >= 6,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("AUTHENTICATE")
        }

        TextButton(
            onClick = onBack,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Back")
        }
    }
}

@Composable
fun ConnectionStatusIndicator(state: com.vinhcommand.domain.model.ConnectionState) {
    val (color, text) = when (state) {
        com.vinhcommand.domain.model.ConnectionState.CONNECTING -> MaterialTheme.colorScheme.primary to "Connecting..."
        com.vinhcommand.domain.model.ConnectionState.AUTHENTICATING -> MaterialTheme.colorScheme.primary to "Authenticating..."
        com.vinhcommand.domain.model.ConnectionState.CONNECTED -> MaterialTheme.colorScheme.tertiary to "Connected"
        com.vinhcommand.domain.model.ConnectionState.RECONNECTING -> MaterialTheme.colorScheme.secondary to "Reconnecting..."
        com.vinhcommand.domain.model.ConnectionState.OFFLINE -> MaterialTheme.colorScheme.onSurfaceVariant to "Offline"
        com.vinhcommand.domain.model.ConnectionState.SESSION_EXPIRED -> MaterialTheme.colorScheme.error to "Session Expired"
        com.vinhcommand.domain.model.ConnectionState.ACCESS_REVOKED -> MaterialTheme.colorScheme.error to "Access Revoked"
        com.vinhcommand.domain.model.ConnectionState.FAILED -> MaterialTheme.colorScheme.error to "Connection Failed"
        else -> MaterialTheme.colorScheme.onSurfaceVariant to "Disconnected"
    }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = Icons.Default.Wifi,
            contentDescription = "Connection",
            tint = color,
            modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = text,
            color = color,
            fontWeight = FontWeight.Medium,
            style = MaterialTheme.typography.bodyMedium
        )
    }
}

class DesktopIdVisualTransformation : VisualTransformation {
    override fun filter(text: androidx.compose.ui.text.AnnotatedString): TransformedText {
        val clean = text.text.replace("\\D".toRegex(), "")
        val formatted = clean.chunked(3).joinToString(" ")
        return TransformedText(
            androidx.compose.ui.text.AnnotatedString(formatted),
            object : OffsetMapping {
                override fun originalToTransformed(offset: Int): Int {
                    if (offset <= 3) return offset
                    if (offset <= 6) return offset + 1
                    if (offset <= 9) return offset + 2
                    return formatted.length
                }
                override fun transformedToOriginal(offset: Int): Int {
                    if (offset <= 3) return offset
                    if (offset <= 7) return offset - 1
                    if (offset <= 11) return offset - 2
                    return clean.length
                }
            }
        )
    }
}
