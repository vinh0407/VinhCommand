package com.vinhcommand.presentation.agents

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.hilt.navigation.compose.hiltViewModel

@Composable
fun AgentsScreen(
    onNavigateBack: () -> Unit,
    viewModel: AgentsViewModel = hiltViewModel()
) {
    Text("Agents Screen Placeholder")
}
