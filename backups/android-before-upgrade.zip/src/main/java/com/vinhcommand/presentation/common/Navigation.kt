package com.vinhcommand.presentation.common

import androidx.compose.runtime.Composable
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.vinhcommand.presentation.connect.ConnectScreen
import com.vinhcommand.presentation.home.HomeScreen
import com.vinhcommand.presentation.agents.AgentsScreen
import com.vinhcommand.presentation.projects.ProjectsScreen
import com.vinhcommand.presentation.projects.ProjectDetailScreen
import com.vinhcommand.presentation.tasks.TasksScreen
import com.vinhcommand.presentation.tasks.TaskDetailScreen
import com.vinhcommand.presentation.tasks.NewTaskScreen
import com.vinhcommand.presentation.terminal.TerminalScreen
import com.vinhcommand.presentation.files.FilesScreen
import com.vinhcommand.presentation.git.GitScreen
import com.vinhcommand.presentation.processes.ProcessesScreen
import com.vinhcommand.presentation.servers.ServersScreen
import com.vinhcommand.presentation.preview.PreviewScreen
import com.vinhcommand.presentation.screen.ScreenStreamScreen
import com.vinhcommand.presentation.security.SecurityScreen
import com.vinhcommand.presentation.settings.SettingsScreen
import dagger.hilt.android.AndroidEntryPoint


@Composable
fun AppNavHost() {
    val navController = rememberNavController()
    val startDestination = if (isFirstLaunch()) "connect" else "home"
    
    NavHost(navController, startDestination = startDestination) {
        composable("connect") {
            ConnectScreen(onNavigateToHome = { navController.navigate("home") { popUpTo("connect") { inclusive = true } } })
        }
        
        composable("home") {
            HomeScreen(
                onNavigateToProjects = { navController.navigate("projects") },
                onNavigateToTasks = { navController.navigate("tasks") },
                onNavigateToAgents = { navController.navigate("agents") },
                onNavigateToTerminal = { navController.navigate("terminal") },
                onNavigateToFiles = { navController.navigate("files") },
                onNavigateToGit = { navController.navigate("git") },
                onNavigateToProcesses = { navController.navigate("processes") },
                onNavigateToServers = { navController.navigate("servers") },
                onNavigateToPreview = { navController.navigate("preview") },
                onNavigateToScreen = { navController.navigate("screen") },
                onNavigateToSecurity = { navController.navigate("security") },
                onNavigateToSettings = { navController.navigate("settings") }
            )
        }
        
        composable("projects") {
            ProjectsScreen(
                onProjectClick = { projectId -> navController.navigate("project_detail/$projectId") },
                onNavigateToTasks = { navController.navigate("tasks") },
                onNavigateToHome = { navController.navigate("home") { popUpTo("projects") { inclusive = true } } }
            )
        }
        
        composable(
            route = "project_detail/{projectId}",
            arguments = listOf(navArgument("projectId") { type = NavType.StringType })
        ) { backStackEntry ->
            val projectId = backStackEntry.arguments?.getString("projectId")!!
            ProjectDetailScreen(
                projectId = projectId,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToGit = { navController.navigate("git") },
                onNavigateToFiles = { navController.navigate("files") },
                onNavigateToTerminal = { navController.navigate("terminal") },
                onNavigateToPreview = { navController.navigate("preview") }
            )
        }
        
        composable("tasks") {
            TasksScreen(
                onTaskClick = { taskId -> navController.navigate("task_detail/$taskId") },
                onNewTask = { navController.navigate("new_task") },
                onNavigateToHome = { navController.navigate("home") { popUpTo("tasks") { inclusive = true } } }
            )
        }
        
        composable(
            route = "task_detail/{taskId}",
            arguments = listOf(navArgument("taskId") { type = NavType.StringType })
        ) { backStackEntry ->
            val taskId = backStackEntry.arguments?.getString("taskId")!!
            TaskDetailScreen(
                taskId = taskId,
                onNavigateBack = { navController.popBackStack() }
            )
        }
        
        composable("new_task") {
            NewTaskScreen(
                onNavigateBack = { navController.popBackStack() },
                onTaskCreated = { taskId -> navController.navigate("task_detail/$taskId") { popUpTo("new_task") { inclusive = true } } }
            )
        }
        
        composable("agents") {
            AgentsScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }
        
        composable("terminal") {
            TerminalScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }
        
        composable("files") {
            FilesScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }
        
        composable("git") {
            GitScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }
        
        composable("processes") {
            ProcessesScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }
        
        composable("servers") {
            ServersScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }
        
        composable("preview") {
            PreviewScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }
        
        composable("screen") {
            ScreenStreamScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }
        
        composable("security") {
            SecurityScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }
        
        composable("settings") {
            SettingsScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }
    }
}

private fun isFirstLaunch(): Boolean {
    // TODO: Check DataStore for first launch
    return true
}
