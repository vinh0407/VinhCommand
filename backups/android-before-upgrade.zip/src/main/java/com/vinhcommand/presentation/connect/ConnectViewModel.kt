package com.vinhcommand.presentation.connect

import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel


import com.vinhcommand.domain.model.*
import com.vinhcommand.domain.usecase.connection.*
import com.vinhcommand.presentation.common.BaseViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ConnectViewModel @Inject constructor(
    private val connectToPcUseCase: ConnectToPcUseCase,
    private val disconnectFromPcUseCase: DisconnectFromPcUseCase,
    private val pairWithPcUseCase: PairWithPcUseCase,
    private val authenticateWithPcUseCase: AuthenticateWithPcUseCase,
    private val trustDeviceUseCase: TrustDeviceUseCase,
    private val observeConnectionStateUseCase: ObserveConnectionStateUseCase,
    private val observePcStateUseCase: ObservePcStateUseCase
) : BaseViewModel() {

    private val _desktopId = MutableStateFlow("123456789")
    val desktopId = _desktopId.asStateFlow()

    private val _accessCode = MutableStateFlow("123456")
    val accessCode = _accessCode.asStateFlow()

    private val _isPairingMode = MutableStateFlow(false)
    val isPairingMode = _isPairingMode.asStateFlow()

    private val _pairingChallenge = MutableStateFlow<PairingChallenge?>(null)
    val pairingChallenge = _pairingChallenge.asStateFlow()

    private val _deviceId = MutableStateFlow("")
    val deviceId = _deviceId.asStateFlow()

    private val _deviceName = MutableStateFlow("Android Device")
    val deviceName = _deviceName.asStateFlow()

    val connectionState = observeConnectionStateUseCase()
    val pcState = observePcStateUseCase()

    fun setDesktopId(id: String) {
        _desktopId.value = id.replace(" ", "")
    }

    fun setAccessCode(code: String) {
        _accessCode.value = code
    }

    fun setPairingMode(enabled: Boolean) {
        _isPairingMode.value = enabled
    }

    fun setDeviceId(id: String) {
        _deviceId.value = id
    }

    fun setDeviceName(name: String) {
        _deviceName.value = name
    }

    fun connect() {
        val desktopId = _desktopId.value
        val accessCode = _accessCode.value
        
        if (desktopId.isBlank() || accessCode.isBlank()) {
            setState(UiState.Error("Please enter Desktop ID and Access Code"))
            return
        }

        setState(UiState.Loading("Connecting..."))
        
        launch {
            val config = ConnectionConfig(
                desktopId = desktopId,
                host = "192.168.1.105", 
                port = 8444,
                accessCode = accessCode
            )
            
            val result = connectToPcUseCase(config)
            result.onSuccess { authResponse ->
                if (authResponse.success) {
                    setState(UiState.Success(authResponse))
                } else {
                    setState(UiState.Error(authResponse.error ?: "Connection failed"))
                }
            }.onFailure { e ->
                setState(UiState.Error(e.message ?: "Connection failed"))
            }
        }
    }

    fun pair() {
        val desktopId = _desktopId.value
        if (desktopId.isBlank()) {
            setState(UiState.Error("Please enter Desktop ID"))
            return
        }

        setState(UiState.Loading("Pairing..."))
        
        launch {
            val request = PairingRequest(
                desktopId = desktopId,
                deviceName = _deviceName.value,
                appVersion = "1.0.0"
            )
            
            val result = pairWithPcUseCase(request)
            result.onSuccess { challenge ->
                _pairingChallenge.value = challenge
                _isPairingMode.value = true
                setState(UiState.Success(challenge))
            }.onFailure { e ->
                setState(UiState.Error(e.message ?: "Pairing failed"))
            }
        }
    }

    fun authenticate() {
        val challenge = _pairingChallenge.value ?: return
        val accessCode = _accessCode.value
        
        if (accessCode.isBlank()) {
            setState(UiState.Error("Please enter access code"))
            return
        }

        setState(UiState.Loading("Authenticating..."))
        
        launch {
            val request = AuthRequest(
                desktopId = challenge.desktopId,
                accessCode = accessCode,
                deviceId = _deviceId.value,
                deviceName = _deviceName.value
            )
            
            val result = authenticateWithPcUseCase(request)
            result.onSuccess { authResponse ->
                if (authResponse.success) {
                    setState(UiState.Success(authResponse))
                } else {
                    setState(UiState.Error(authResponse.error ?: "Authentication failed"))
                }
            }.onFailure { e ->
                setState(UiState.Error(e.message ?: "Authentication failed"))
            }
        }
    }

    fun trustDevice(trust: Boolean) {
        launch {
            val request = DeviceTrustRequest(
                deviceId = _deviceId.value,
                trust = trust,
                sessionToken = "" // TODO: Get from session
            )
            
            val result = trustDeviceUseCase(request)
            result.onSuccess {
                setState(UiState.Success(Unit))
            }.onFailure { e ->
                setState(UiState.Error(e.message ?: "Failed to set trust"))
            }
        }
    }

    fun disconnect() {
        launch {
            disconnectFromPcUseCase(Unit)
            _desktopId.value = ""
            _accessCode.value = ""
            _isPairingMode.value = false
            _pairingChallenge.value = null
            setState(UiState.Idle)
        }
    }

    fun formatDesktopId(input: String): String {
        val clean = input.replace("\\D".toRegex(), "")
        if (clean.length <= 9) {
            return clean.chunked(3).joinToString(" ")
        }
        return clean.take(9).chunked(3).joinToString(" ")
    }

    fun validateDesktopId(id: String): Boolean {
        val clean = id.replace("\\s+".toRegex(), "")
        return clean.length == 9 && clean.all { it.isDigit() }
    }

    fun validateAccessCode(code: String): Boolean {
        return code.length >= 6
    }
}

